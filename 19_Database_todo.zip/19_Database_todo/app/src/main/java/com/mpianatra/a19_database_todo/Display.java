package com.mpianatra.a19_database_todo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Display extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
    }
}