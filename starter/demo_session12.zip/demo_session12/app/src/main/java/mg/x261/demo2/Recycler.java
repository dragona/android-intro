package mg.x261.demo2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

//TODO: specify the data to be used
//      custom adapter
//      load the adapter in the recyclerview
//      specify the layoutManager to use (GridLayoutmanager)


public class Recycler extends AppCompatActivity {

    ArrayList<ObjectItem> objectItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_recycler_view);

        objectItems = new ArrayList<>();

        objectItems.add(new ObjectItem("countryName", R.drawable.flag_china, "continentName"));
        objectItems.add(new ObjectItem("countryName", R.drawable.flag_france, "continentName"));
        objectItems.add(new ObjectItem("countryName", R.drawable.flag_mauritius, "continentName"));
        objectItems.add(new ObjectItem("countryName", R.drawable.flag_australia, "continentName"));
        objectItems.add(new ObjectItem("countryName", R.drawable.flag_madagascar, "continentName"));
        CustomAdapter customAdapter = new CustomAdapter(objectItems);
        //

        RecyclerView recyclerView = findViewById(R.id.myRecyclerView);
        recyclerView.setAdapter(customAdapter);
        int columns = 2;
        recyclerView.setLayoutManager(new GridLayoutManager(this, columns));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
    }


}