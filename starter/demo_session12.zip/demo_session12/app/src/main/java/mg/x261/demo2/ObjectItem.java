package mg.x261.demo2;

public class ObjectItem {

    String countryName;
    String continentName;
    int imageFlagId;

    public ObjectItem(String countryName, int flag_china, String continentName) {
        this.countryName = countryName;
        this.continentName = continentName;
        this.imageFlagId = flag_china;
    }


    public String getCountryName() {
        return countryName;
    }

    public String getContinentName() {
        return continentName;
    }

    public int getImageFlagId() {
        return imageFlagId;
    }
}
