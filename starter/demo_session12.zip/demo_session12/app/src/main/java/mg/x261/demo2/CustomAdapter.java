package mg.x261.demo2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {
    private ArrayList<ObjectItem> localDataset;

    public CustomAdapter(ArrayList<ObjectItem> dataset) {
        localDataset = dataset;
    }

    @NonNull
    @Override
    public CustomAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.ViewHolder holder, int position) {

        ObjectItem currentItem = localDataset.get(position);

        ImageView imageView = holder.imageViewFlag;
        imageView.setImageResource(currentItem.getImageFlagId());

        TextView continentName = holder.txtContinentName;
        continentName.setText(currentItem.getContinentName());



        TextView txtCountryName = holder.txtCountryName;
        txtCountryName.setText(currentItem.getCountryName());


    }

    @Override
    public int getItemCount() {
        return localDataset.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtContinentName;
        TextView txtCountryName;
        ImageView imageViewFlag;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtContinentName = itemView.findViewById(R.id.txtContinentName);
            txtCountryName = itemView.findViewById(R.id.txtCountryName);
            imageViewFlag = itemView.findViewById(R.id.imageViewFlag);
        }
    }
}
