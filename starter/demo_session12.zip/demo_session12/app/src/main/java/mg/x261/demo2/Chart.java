package mg.x261.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import java.util.ArrayList;

public class Chart extends AppCompatActivity {

    //    Data
    private static final String[] DAYS = {"Mon", "Tue", "Wen", "Thu", "Fri", "Sat", "Sun"};
    private static final  String SET_LABEL = " This is the label";
    private BarChart chart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);

        chart = findViewById(R.id.myChart);

        BarData data = createChatData();
        configureChartAppearance();
        prepareChartData(data);


    }

    private void prepareChartData(BarData data) {
        data.setValueTextSize(12f);
        chart.setData(data);
        chart.invalidate();

    }

    private void configureChartAppearance() {
        // TODO: check the doc for the detail
        chart.getDescription().setEnabled(false);
        chart.setDrawValueAboveBar(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return DAYS[(int) value];
            }
        });

        YAxis axisLeft = chart.getAxisLeft();
        axisLeft.setGranularity(10f);
        axisLeft.setAxisMinimum(0);

        YAxis axisRight = chart.getAxisRight();
        axisRight.setGranularity(10f);
        axisRight.setAxisMinimum(0);

    }

    private BarData createChatData() {
        ArrayList<BarEntry> values = new ArrayList<>();
        values.add(new BarEntry(0, 16));
        values.add(new BarEntry(1, 23));
        values.add(new BarEntry(2, 16));
        values.add(new BarEntry(3, 45));
        values.add(new BarEntry(4, 36));
        values.add(new BarEntry(5, 18));
        values.add(new BarEntry(6, 46));

        BarDataSet setData = new BarDataSet(values, SET_LABEL);
        ArrayList<IBarDataSet> dataSets = new ArrayList<>();
        dataSets.add(setData);
        return new BarData(dataSets);
    }
}