# Fragment - 

Topic covered:
- Fragment manager (fragment back stack)
- 