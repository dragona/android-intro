package mg.x261.demofragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import mg.x261.demofragment.databinding.FragmentTitleBinding

class TitleFragment : Fragment() {
    //Inflating and Returning the View with DataBindingUtil
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = DataBindingUtil.inflate<FragmentTitleBinding>(
            inflater,
            R.layout.fragment_title,
            container,
            false
        )

        // method 1:
//        binding.startButton.setOnClickListener {
//            // The navigation fragment is the host of our fragments.
//            // Thus we need to navigate it to access the other fragments
//
//             View -> Navigation.findNavController(View)
//             .navigate(R.id.action_titleFragment_to_gameFragment)
//        }
        // method 2:
        // use navigation to create the on click listener
        binding.startButton.setOnClickListener(
            Navigation.createNavigateOnClickListener(R.id.action_titleFragment_to_gameFragment)
        )


        return binding.root
    }


}